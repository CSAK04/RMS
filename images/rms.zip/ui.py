from tkinter import *
import customtkinter


def login():
    pass
    
    
    
a = customtkinter.CTkToplevel()
a.geometry('900x600')

a.mainloop()
